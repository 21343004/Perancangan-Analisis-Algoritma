import sys
from sys import argv

filename = sys.argv[1] if len(sys.argv) > 1 else 'bacafile.txt'

text = open(filename)

print("Lirik lagu favorit {filename} : ")
print(text.read())