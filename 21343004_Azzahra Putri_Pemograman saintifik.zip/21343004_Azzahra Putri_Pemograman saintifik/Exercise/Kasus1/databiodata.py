import sys
from sys import argv

filename = sys.argv[1] if len(sys.argv) > 1 else 'databiodata.txt'

print(f"Membuka {filename}")
text = open(filename, 'w')

nama = input("Nama   : ")
nim = input("NIM    : ")
alamat = input("Alamat : ")

text.write(nama)
text.write("\n")
text.write(nim)
text.write("\n")
text.write(alamat)
text.write("\n")

print("Data sudah disimpan pada {filename}")
text.close()
